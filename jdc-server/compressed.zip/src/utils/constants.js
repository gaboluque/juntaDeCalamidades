module.exports = {
  port: process.env.PORT || 3000,
  roomName: "JuntaDeCalamidades",
  botName: "Rey Fracaso",
}